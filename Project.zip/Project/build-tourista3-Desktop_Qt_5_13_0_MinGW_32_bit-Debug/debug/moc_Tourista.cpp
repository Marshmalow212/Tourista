/****************************************************************************
** Meta object code from reading C++ file 'Tourista.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../tourista3/Tourista.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Tourista.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Tourista_t {
    QByteArrayData data[39];
    char stringdata0[920];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Tourista_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Tourista_t qt_meta_stringdata_Tourista = {
    {
QT_MOC_LITERAL(0, 0, 8), // "Tourista"
QT_MOC_LITERAL(1, 9, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(4, 56, 24), // "on_pushButton_18_clicked"
QT_MOC_LITERAL(5, 81, 24), // "on_pushButton_24_clicked"
QT_MOC_LITERAL(6, 106, 24), // "on_pushButton_14_clicked"
QT_MOC_LITERAL(7, 131, 24), // "on_pushButton_15_clicked"
QT_MOC_LITERAL(8, 156, 24), // "on_checkBox_stateChanged"
QT_MOC_LITERAL(9, 181, 4), // "arg1"
QT_MOC_LITERAL(10, 186, 32), // "on_comboBox_4_currentTextChanged"
QT_MOC_LITERAL(11, 219, 30), // "on_comboBox_currentTextChanged"
QT_MOC_LITERAL(12, 250, 32), // "on_comboBox_2_currentTextChanged"
QT_MOC_LITERAL(13, 283, 24), // "on_pushButton_17_clicked"
QT_MOC_LITERAL(14, 308, 26), // "on_checkBox_2_stateChanged"
QT_MOC_LITERAL(15, 335, 32), // "on_comboBox_7_currentTextChanged"
QT_MOC_LITERAL(16, 368, 23), // "on_comboBox_9_activated"
QT_MOC_LITERAL(17, 392, 5), // "index"
QT_MOC_LITERAL(18, 398, 33), // "on_comboBox_6_currentIndexCha..."
QT_MOC_LITERAL(19, 432, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(20, 456, 24), // "on_pushButton_16_clicked"
QT_MOC_LITERAL(21, 481, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(22, 505, 24), // "on_pushButton_12_clicked"
QT_MOC_LITERAL(23, 530, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(24, 554, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(25, 578, 28), // "on_textBrowser_4_textChanged"
QT_MOC_LITERAL(26, 607, 23), // "on_comboBox_4_activated"
QT_MOC_LITERAL(27, 631, 20), // "on_submitbtn_clicked"
QT_MOC_LITERAL(28, 652, 20), // "on_cancelbtn_clicked"
QT_MOC_LITERAL(29, 673, 19), // "on_donbuttn_clicked"
QT_MOC_LITERAL(30, 693, 19), // "on_canbuttn_clicked"
QT_MOC_LITERAL(31, 713, 19), // "on_paybuttn_clicked"
QT_MOC_LITERAL(32, 733, 19), // "on_hisbuttn_clicked"
QT_MOC_LITERAL(33, 753, 24), // "on_pushButton_13_clicked"
QT_MOC_LITERAL(34, 778, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(35, 802, 34), // "on_guiddivcombo_currentTextCh..."
QT_MOC_LITERAL(36, 837, 34), // "on_guidplccombo_currentTextCh..."
QT_MOC_LITERAL(37, 872, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(38, 896, 23) // "on_pushButton_6_clicked"

    },
    "Tourista\0on_pushButton_clicked\0\0"
    "on_pushButton_2_clicked\0"
    "on_pushButton_18_clicked\0"
    "on_pushButton_24_clicked\0"
    "on_pushButton_14_clicked\0"
    "on_pushButton_15_clicked\0"
    "on_checkBox_stateChanged\0arg1\0"
    "on_comboBox_4_currentTextChanged\0"
    "on_comboBox_currentTextChanged\0"
    "on_comboBox_2_currentTextChanged\0"
    "on_pushButton_17_clicked\0"
    "on_checkBox_2_stateChanged\0"
    "on_comboBox_7_currentTextChanged\0"
    "on_comboBox_9_activated\0index\0"
    "on_comboBox_6_currentIndexChanged\0"
    "on_pushButton_3_clicked\0"
    "on_pushButton_16_clicked\0"
    "on_pushButton_8_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_pushButton_7_clicked\0on_pushButton_4_clicked\0"
    "on_textBrowser_4_textChanged\0"
    "on_comboBox_4_activated\0on_submitbtn_clicked\0"
    "on_cancelbtn_clicked\0on_donbuttn_clicked\0"
    "on_canbuttn_clicked\0on_paybuttn_clicked\0"
    "on_hisbuttn_clicked\0on_pushButton_13_clicked\0"
    "on_pushButton_9_clicked\0"
    "on_guiddivcombo_currentTextChanged\0"
    "on_guidplccombo_currentTextChanged\0"
    "on_pushButton_5_clicked\0on_pushButton_6_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Tourista[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  189,    2, 0x08 /* Private */,
       3,    0,  190,    2, 0x08 /* Private */,
       4,    0,  191,    2, 0x08 /* Private */,
       5,    0,  192,    2, 0x08 /* Private */,
       6,    0,  193,    2, 0x08 /* Private */,
       7,    0,  194,    2, 0x08 /* Private */,
       8,    1,  195,    2, 0x08 /* Private */,
      10,    1,  198,    2, 0x08 /* Private */,
      11,    1,  201,    2, 0x08 /* Private */,
      12,    1,  204,    2, 0x08 /* Private */,
      13,    0,  207,    2, 0x08 /* Private */,
      14,    1,  208,    2, 0x08 /* Private */,
      15,    1,  211,    2, 0x08 /* Private */,
      16,    1,  214,    2, 0x08 /* Private */,
      18,    1,  217,    2, 0x08 /* Private */,
      19,    0,  220,    2, 0x08 /* Private */,
      20,    0,  221,    2, 0x08 /* Private */,
      21,    0,  222,    2, 0x08 /* Private */,
      22,    0,  223,    2, 0x08 /* Private */,
      23,    0,  224,    2, 0x08 /* Private */,
      24,    0,  225,    2, 0x08 /* Private */,
      25,    0,  226,    2, 0x08 /* Private */,
      26,    1,  227,    2, 0x08 /* Private */,
      27,    0,  230,    2, 0x08 /* Private */,
      28,    0,  231,    2, 0x08 /* Private */,
      29,    0,  232,    2, 0x08 /* Private */,
      30,    0,  233,    2, 0x08 /* Private */,
      31,    0,  234,    2, 0x08 /* Private */,
      32,    0,  235,    2, 0x08 /* Private */,
      33,    0,  236,    2, 0x08 /* Private */,
      34,    0,  237,    2, 0x08 /* Private */,
      35,    1,  238,    2, 0x08 /* Private */,
      36,    1,  241,    2, 0x08 /* Private */,
      37,    0,  244,    2, 0x08 /* Private */,
      38,    0,  245,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Tourista::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Tourista *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: _t->on_pushButton_2_clicked(); break;
        case 2: _t->on_pushButton_18_clicked(); break;
        case 3: _t->on_pushButton_24_clicked(); break;
        case 4: _t->on_pushButton_14_clicked(); break;
        case 5: _t->on_pushButton_15_clicked(); break;
        case 6: _t->on_checkBox_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_comboBox_4_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->on_comboBox_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->on_comboBox_2_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_pushButton_17_clicked(); break;
        case 11: _t->on_checkBox_2_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_comboBox_7_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->on_comboBox_9_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_comboBox_6_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->on_pushButton_3_clicked(); break;
        case 16: _t->on_pushButton_16_clicked(); break;
        case 17: _t->on_pushButton_8_clicked(); break;
        case 18: _t->on_pushButton_12_clicked(); break;
        case 19: _t->on_pushButton_7_clicked(); break;
        case 20: _t->on_pushButton_4_clicked(); break;
        case 21: _t->on_textBrowser_4_textChanged(); break;
        case 22: _t->on_comboBox_4_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 23: _t->on_submitbtn_clicked(); break;
        case 24: _t->on_cancelbtn_clicked(); break;
        case 25: _t->on_donbuttn_clicked(); break;
        case 26: _t->on_canbuttn_clicked(); break;
        case 27: _t->on_paybuttn_clicked(); break;
        case 28: _t->on_hisbuttn_clicked(); break;
        case 29: _t->on_pushButton_13_clicked(); break;
        case 30: _t->on_pushButton_9_clicked(); break;
        case 31: _t->on_guiddivcombo_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 32: _t->on_guidplccombo_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 33: _t->on_pushButton_5_clicked(); break;
        case 34: _t->on_pushButton_6_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Tourista::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_Tourista.data,
    qt_meta_data_Tourista,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Tourista::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Tourista::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Tourista.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Tourista::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 35)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 35;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
